package com.tienda.productos.entity;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "apisperu")
public class ApisPeruProperties {

    private String token;
    private String urlRuc;
    private String urlDni;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUrlRuc() {
        return urlRuc;
    }

    public void setUrlRuc(String urlRuc) {
        this.urlRuc = urlRuc;
    }

    public String getUrlDni() {
        return urlDni;
    }

    public void setUrlDni(String urlDni) {
        this.urlDni = urlDni;
    }
}
